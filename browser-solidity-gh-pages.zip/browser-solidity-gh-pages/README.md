# browser-solidity

This is the former repository of remix-ide (aka browser-solidity).

Now available at https://github.com/ethereum/remix-ide
